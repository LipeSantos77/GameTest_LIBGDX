package br.jogobike;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

public class GameScreen implements Screen {
    private MainGame game;
    private OrthographicCamera camera;
    private FitViewport viewport;
    private Texture background;
    private Texture playerTexture;
    private Texture botTexture;

    // Constantes para a Viewport
    private static final float VIRTUAL_WIDTH = 800;
    private static final float VIRTUAL_HEIGHT = 800;

    private float playerX, playerY;
    private float botX, botY;

    // VARIÁVEIS PARA DINÂMICA DE MOVIMENTO
    private float playerSpeedX = 0;
    private float playerSpeedY = 0;
    private float maxSpeed = 400f;
    private float acceleration = 300f;
    private float friction = 200f;
    private float driftSpeed = 150f;

    // SISTEMA DE VIDAS E PONTOS
    private int pontos = 100;
    private int vidas = 3;
    private boolean podeLevarDano = true;
    private float tempoInvencivel = 0f;
    private final float TEMPO_INVENCIBILIDADE = 1.5f;

    // Sistema de dano na avalanche
    private float tempoUltimoDanoAvalanche = 0f;
    private final float INTERVALO_DANO_AVALANCHE = 0.3f;

    // Tamanhos dos sprites VISUAIS
    private final float PLAYER_WIDTH = 70f;
    private final float PLAYER_HEIGHT = 90f;
    private final float BOT_WIDTH = 70f;
    private final float BOT_HEIGHT = 75f;

    // Tamanhos das áreas de COLISÃO
    private final float PLAYER_COLLISION_WIDTH = 40f;
    private final float PLAYER_COLLISION_HEIGHT = 40f;
    private final float BOT_COLLISION_WIDTH = 40f;
    private final float BOT_COLLISION_HEIGHT = 40f;

    // Offset para centralizar a área de colisão
    private final float PLAYER_COLLISION_OFFSET_X = (PLAYER_WIDTH - PLAYER_COLLISION_WIDTH) / 2f;
    private final float PLAYER_COLLISION_OFFSET_Y = (PLAYER_HEIGHT - PLAYER_COLLISION_HEIGHT) / 2f;
    private final float BOT_COLLISION_OFFSET_X = (BOT_WIDTH - BOT_COLLISION_WIDTH) / 2f;
    private final float BOT_COLLISION_OFFSET_Y = (BOT_HEIGHT - BOT_COLLISION_HEIGHT) / 2f;

    // LIMITES DA PISTA
    private final float PISTA_BAIXO = 275f;
    private final float PISTA_CIMA = 500f;

    // AVALANCHE - sistema realista
    private final float LARGURA_AVALANCHE = 120f;
    private final float ALTURA_AVALANCHE = 520f;
    private ShapeRenderer shapeRenderer;
    private Random random;
    private List<SnowEffect> snowEffects;
    private float avalancheTimer = 0f;
    private float avalancheIntensity = 0f;

    // SISTEMA DE VENTO - CORRIGIDO (esquerda para direita)
    private List<WindLine> windLines;
    private float windTimer = 0f;

    // Linhas de vento para efeito de velocidade - CORRIGIDO
    private class WindLine {
        float x, y;
        float length;
        float speed;
        float thickness;
        float alpha;
        boolean isActive;

        public WindLine() {
            reset();
        }

        public void reset() {
            this.x = -50; // Começa fora da tela à ESQUERDA
            this.y = (float) (Math.random() * VIRTUAL_HEIGHT);
            this.length = (float) (Math.random() * 60 + 30); // Mais curtas para naturalidade
            this.speed = (float) (Math.random() * 100 + 150); // Velocidade constante
            this.thickness = (float) (Math.random() * 2 + 1); // Mais finas
            this.alpha = (float) (Math.random() * 0.3 + 0.2); // Mais transparente
            this.isActive = true;
        }

        public void update(float delta, float playerSpeed) {
            // Movimento da ESQUERDA para DIREITA
            x += speed * delta;

            // Efeito de fade out suave
            alpha -= 0.5f * delta;

            // Reinicia se saiu da tela ou ficou transparente
            if (x > VIRTUAL_WIDTH + 100 || alpha <= 0) {
                reset();
            }
        }
    }

    // Sistema de efeitos de neve - fumaça e bolas
    private class SnowEffect {
        float x, y;
        float size;
        float speed;
        float life;
        float maxLife;
        float rotation;
        float rotationSpeed;
        boolean isSnowball; // true = bola de neve, false = fumaça
        Color color;

        public SnowEffect() {
            this.isSnowball = random.nextBoolean(); // 50% chance de ser bola ou fumaça
            this.x = (float) (Math.random() * LARGURA_AVALANCHE);

            if (isSnowball) {
                // BOLA DE NEVE - mais compacta, menor
                this.size = (float) (Math.random() * 12 + 8);
                this.y = (float) (Math.random() * ALTURA_AVALANCHE);
                this.speed = (float) (Math.random() * 80 + 40) + avalancheIntensity * 80;
                this.maxLife = (float) (Math.random() * 4 + 3);
                this.color = new Color(1, 1, 1, 0.9f); // Branco sólido
            } else {
                // FUMAÇA DE NEVE - maior, mais difusa
                this.size = (float) (Math.random() * 25 + 15);
                this.y = (float) (Math.random() * ALTURA_AVALANCHE);
                this.speed = (float) (Math.random() * 60 + 30) + avalancheIntensity * 60;
                this.maxLife = (float) (Math.random() * 2 + 1.5f);
                this.color = new Color(1, 1, 1, 0.6f); // Branco translúcido
            }

            this.life = maxLife;
            this.rotation = (float) (Math.random() * 360);
            this.rotationSpeed = (float) (Math.random() * 100 - 50); // Rotação aleatória
        }

        public void update(float delta) {
            // Movimento para direita (avanço da avalanche)
            x += speed * delta;
            rotation += rotationSpeed * delta;
            life -= delta;

            if (isSnowball) {
                // Comportamento da BOLA DE NEVE
                size += 8f * delta; // Cresce lentamente
                color.a = life / maxLife * 0.9f; // Fade out suave
            } else {
                // Comportamento da FUMAÇA
                size += 25f * delta; // Cresce rapidamente (expansão)
                color.a = (life / maxLife) * 0.6f; // Fade out mais rápido

                // Movimento vertical leve para fumaça
                y += (float) (Math.sin(avalancheTimer * 3 + x * 0.01f) * 20 * delta);
            }
        }

        public boolean isDead() {
            return life <= 0 || x > LARGURA_AVALANCHE + 100 || (isSnowball && size > 50) || (!isSnowball && size > 80);
        }
    }

    private Rectangle playerRect;
    private Rectangle botRect;

    public GameScreen(MainGame game, int level) {
        this.game = game;
        this.random = new Random();

        camera = new OrthographicCamera();
        viewport = new FitViewport(VIRTUAL_WIDTH, VIRTUAL_HEIGHT, camera);
        camera.setToOrtho(false, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);

        shapeRenderer = new ShapeRenderer();
        snowEffects = new ArrayList<>();
        windLines = new ArrayList<>();

        // Inicializar linhas de vento - menos linhas para mais naturalidade
        for (int i = 0; i < 15; i++) {
            windLines.add(new WindLine());
        }

        // Carregar texturas
        try {
            background = new Texture(Gdx.files.internal("background.png"));
            playerTexture = new Texture(Gdx.files.internal("player_bike.png"));
            botTexture = new Texture(Gdx.files.internal("bot_bike.jpeg"));
        } catch (Exception e) {
            Gdx.app.error("GameScreen", "Erro ao carregar texturas: " + e.getMessage());
            background = createPlaceholderTexture((int)VIRTUAL_WIDTH, (int)VIRTUAL_HEIGHT, Color.GRAY);
            playerTexture = createPlaceholderTexture((int)PLAYER_WIDTH, (int)PLAYER_HEIGHT, Color.BLUE);
            botTexture = createPlaceholderTexture((int)BOT_WIDTH, (int)BOT_HEIGHT, Color.RED);
        }

        // Posições iniciais (Jogador no centro)
        playerX = VIRTUAL_WIDTH / 2f - PLAYER_WIDTH / 2f;
        playerY = VIRTUAL_HEIGHT / 2f - PLAYER_HEIGHT / 2f;

        // Bot inicial fora da tela à direita
        botX = VIRTUAL_WIDTH + 50;
        botY = getRandomPositionInTrack();

        playerRect = new Rectangle(
            playerX + PLAYER_COLLISION_OFFSET_X,
            playerY + PLAYER_COLLISION_OFFSET_Y,
            PLAYER_COLLISION_WIDTH,
            PLAYER_COLLISION_HEIGHT
        );

        botRect = new Rectangle(
            botX + BOT_COLLISION_OFFSET_X,
            botY + BOT_COLLISION_OFFSET_Y,
            BOT_COLLISION_WIDTH,
            BOT_COLLISION_HEIGHT
        );
    }

    // Posição vertical aleatória dentro da pista
    private float getRandomPositionInTrack() {
        return PISTA_BAIXO + (float) (random.nextFloat() * (PISTA_CIMA - PISTA_BAIXO - BOT_HEIGHT));
    }

    private Texture createPlaceholderTexture(int width, int height, Color color) {
        com.badlogic.gdx.graphics.Pixmap pixmap = new com.badlogic.gdx.graphics.Pixmap(width, height, com.badlogic.gdx.graphics.Pixmap.Format.RGBA8888);
        pixmap.setColor(color);
        pixmap.fill();
        Texture texture = new Texture(pixmap);
        pixmap.dispose();
        return texture;
    }

    // Atualizar efeito da avalanche realista
    private void updateAvalanche(float delta) {
        avalancheTimer += delta;

        // Intensidade da avalanche aumenta com o tempo
        avalancheIntensity = Math.min(1.0f, avalancheTimer * 0.1f);

        // Spawn de efeitos de neve - mais frequente
        if (random.nextFloat() < 0.6f + avalancheIntensity * 0.4f) {
            snowEffects.add(new SnowEffect());
        }

        // Atualizar efeitos
        for (int i = snowEffects.size() - 1; i >= 0; i--) {
            SnowEffect effect = snowEffects.get(i);
            effect.update(delta);

            if (effect.isDead()) {
                snowEffects.remove(i);
            }
        }
    }

    // Atualizar efeito de vento - CORRIGIDO
    private void updateWindEffect(float delta) {
        windTimer += delta;

        for (WindLine line : windLines) {
            line.update(delta, playerSpeedX);
        }
    }

    // Desenhar efeito de vento - CORRIGIDO
    private void drawWindEffect() {
        shapeRenderer.setProjectionMatrix(camera.combined);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);

        shapeRenderer.begin(ShapeType.Filled);

        for (WindLine line : windLines) {
            if (line.isActive) {
                // Cor branca com transparência variável
                shapeRenderer.setColor(1, 1, 1, line.alpha);

                // Linha da ESQUERDA para DIREITA
                float angle = (float) (Math.sin(windTimer * 1.5f + line.y * 0.02f) * 0.05f); // Menos inclinação
                float endX = line.x + line.length; // Para a direita
                float endY = line.y + angle * line.length;

                // Linha principal
                shapeRenderer.rectLine(line.x, line.y, endX, endY, line.thickness);

                // Efeito de "entrada" mais transparente no início
                shapeRenderer.setColor(1, 1, 1, line.alpha * 0.3f);
                float startLength = line.length * 0.2f;
                float startX = line.x - startLength; // Para a esquerda
                float startY = line.y - angle * startLength;
                shapeRenderer.rectLine(line.x, line.y, startX, startY, line.thickness * 0.5f);
            }
        }

        shapeRenderer.end();

        // Efeito de partículas de vento (pontos brancos) - CORRIGIDO
        shapeRenderer.begin(ShapeType.Filled);

        for (WindLine line : windLines) {
            if (line.isActive && line.alpha > 0.1f) {
                shapeRenderer.setColor(1, 1, 1, line.alpha * 0.6f);

                // Partículas distribuídas ao longo da linha
                for (int i = 0; i < 2; i++) { // Menos partículas
                    float progress = (float) (Math.random() * 0.8 + 0.2); // 20% a 100% do comprimento
                    float particleX = line.x + line.length * progress;
                    float particleY = line.y + (float) (Math.sin(windTimer * 2 + particleX * 0.03f) * 4f); // Menos movimento
                    float particleSize = (float) (Math.random() * 1.5 + 0.5); // Partículas menores
                    shapeRenderer.circle(particleX, particleY, particleSize);
                }
            }
        }

        shapeRenderer.end();

        Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    // Desenhar avalanche com efeitos de fumaça e bolas
    private void drawAvalanche() {
        shapeRenderer.setProjectionMatrix(camera.combined);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);

        // Base sólida da avalanche - massa branca compacta
        shapeRenderer.begin(ShapeType.Filled);

        // Fundo branco sólido da avalanche
        shapeRenderer.setColor(1, 1, 1, 0.95f);
        shapeRenderer.rect(0, 0, LARGURA_AVALANCHE, ALTURA_AVALANCHE);

        shapeRenderer.end();

        // Efeitos de neve (fumaça e bolas) - desenho especializado
        shapeRenderer.begin(ShapeType.Filled);

        for (SnowEffect effect : snowEffects) {
            shapeRenderer.setColor(effect.color);

            if (effect.isSnowball) {
                // Desenhar BOLA DE NEVE - círculo sólido com brilho
                shapeRenderer.circle(effect.x, effect.y, effect.size);

                // Brilho na bola de neve
                shapeRenderer.setColor(1, 1, 1, effect.color.a * 0.3f);
                shapeRenderer.circle(effect.x - effect.size * 0.2f, effect.y + effect.size * 0.2f, effect.size * 0.6f);
                shapeRenderer.setColor(effect.color);

            } else {
                // Desenhar FUMAÇA - múltiplos círculos sobrepostos para efeito orgânico
                shapeRenderer.circle(effect.x, effect.y, effect.size);
                shapeRenderer.circle(effect.x + effect.size * 0.3f, effect.y - effect.size * 0.2f, effect.size * 0.7f);
                shapeRenderer.circle(effect.x - effect.size * 0.2f, effect.y + effect.size * 0.3f, effect.size * 0.5f);

                // Núcleo mais denso da fumaça
                shapeRenderer.setColor(1, 1, 1, effect.color.a * 0.8f);
                shapeRenderer.circle(effect.x, effect.y, effect.size * 0.4f);
                shapeRenderer.setColor(effect.color);
            }
        }

        shapeRenderer.end();

        // Contorno da avalanche - frente irregular
        shapeRenderer.begin(ShapeType.Filled);
        shapeRenderer.setColor(1, 1, 1, 1);

        // Criar frente irregular da avalanche
        float time = avalancheTimer * 2f;
        for (float y = 0; y < ALTURA_AVALANCHE; y += 10) {
            float wave = (float) Math.sin(y * 0.1f + time) * 8f;
            float wave2 = (float) Math.cos(y * 0.05f + time * 1.5f) * 5f;
            float irregularity = (float) Math.sin(y * 0.02f) * 3f;

            float frontX = LARGURA_AVALANCHE + wave + wave2 + irregularity;
            shapeRenderer.rect(LARGURA_AVALANCHE, y, frontX - LARGURA_AVALANCHE, 10);
        }

        shapeRenderer.end();

        Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    private void aplicarDano() {
        if (podeLevarDano) {
            vidas--;
            pontos = Math.max(0, pontos - 20);
            podeLevarDano = false;
            tempoInvencivel = TEMPO_INVENCIBILIDADE;
            playerX = Math.min(VIRTUAL_WIDTH - PLAYER_WIDTH - 100, playerX + 80);
            playerSpeedX = 100;
            Gdx.app.log("GameScreen", "Vidas restantes: " + vidas);
        }
    }

    private void aplicarDanoAvalanche() {
        if (podeLevarDano) {
            vidas--;
            pontos = Math.max(0, pontos - 15);
            podeLevarDano = false;
            tempoInvencivel = TEMPO_INVENCIBILIDADE;
            playerX = LARGURA_AVALANCHE + 30;
            playerSpeedX = 200;
            Gdx.app.log("GameScreen", "Avalanche! Vidas restantes: " + vidas);
        }
    }

    @Override
    public void render(float delta) {
        if (!podeLevarDano) {
            tempoInvencivel -= delta;
            if (tempoInvencivel <= 0) {
                podeLevarDano = true;
            }
        }

        tempoUltimoDanoAvalanche += delta;
        updateAvalanche(delta);
        updateWindEffect(delta);

        Gdx.gl.glClearColor(0.1f, 0.1f, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // --- LÓGICA DE MOVIMENTO ---
        boolean isMovingUp = Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.UP);
        boolean isMovingDown = Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.DOWN);
        boolean isAccelerating = Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.RIGHT);
        boolean isBraking = Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.LEFT);

        // MOVIMENTO HORIZONTAL
        if (isAccelerating) {
            playerSpeedX += acceleration * delta;
            playerSpeedX = Math.min(maxSpeed, playerSpeedX);
        } else if (isBraking) {
            playerSpeedX -= acceleration * 1.5f * delta;
            playerSpeedX = Math.max(-maxSpeed * 0.5f, playerSpeedX);
        } else {
            playerSpeedX -= driftSpeed * delta;
        }

        if (playerSpeedX > 0) {
            playerSpeedX = Math.max(0, playerSpeedX - friction * delta * 0.5f);
        } else if (playerSpeedX < 0) {
            playerSpeedX = Math.min(0, playerSpeedX + friction * delta * 0.5f);
        }

        // MOVIMENTO VERTICAL
        if (isMovingUp) {
            playerSpeedY = maxSpeed * 0.7f;
        } else if (isMovingDown) {
            playerSpeedY = -maxSpeed * 0.7f;
        } else {
            if (playerSpeedY > 0) {
                playerSpeedY = Math.max(0, playerSpeedY - friction * delta);
            } else if (playerSpeedY < 0) {
                playerSpeedY = Math.min(0, playerSpeedY + friction * delta);
            }
        }

        // APLICAR MOVIMENTO
        playerX += playerSpeedX * delta;
        playerY += playerSpeedY * delta;

        // LIMITES DA TELA
        playerX = MathUtils.clamp(playerX, LARGURA_AVALANCHE, VIRTUAL_WIDTH - PLAYER_WIDTH);
        playerY = MathUtils.clamp(playerY, PISTA_BAIXO, PISTA_CIMA - PLAYER_HEIGHT);

        // ÁREA DE DANO DA AVALANCHE
        if (playerX <= LARGURA_AVALANCHE + 5 && podeLevarDano && tempoUltimoDanoAvalanche >= INTERVALO_DANO_AVALANCHE) {
            aplicarDanoAvalanche();
            tempoUltimoDanoAvalanche = 0f;
        }

        // Movimento do bot
        float botSpeed = 200f + (Math.abs(playerSpeedX) * 0.5f);
        botX -= botSpeed * delta;

        if (botX + BOT_WIDTH < LARGURA_AVALANCHE) {
            botX = VIRTUAL_WIDTH + 50;
            botY = getRandomPositionInTrack();
        }

        // Colisões com bots
        playerRect.setPosition(playerX + PLAYER_COLLISION_OFFSET_X, playerY + PLAYER_COLLISION_OFFSET_Y);
        botRect.setPosition(botX + BOT_COLLISION_OFFSET_X, botY + BOT_COLLISION_OFFSET_Y);

        if (playerRect.overlaps(botRect) && podeLevarDano) {
            aplicarDano();
            botX = Math.max(VIRTUAL_WIDTH + 50, botX + 100);
        }

        camera.update();

        // --- DESENHAR TUDO ---
        viewport.apply();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.draw(background, 0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
        game.batch.end();

        drawAvalanche();
        drawWindEffect();

        game.batch.begin();

        if (podeLevarDano || (int)(tempoInvencivel * 10) % 2 == 0) {
            game.batch.draw(playerTexture, playerX, playerY, PLAYER_WIDTH, PLAYER_HEIGHT);
        }

        game.batch.draw(botTexture, botX, botY, BOT_WIDTH, BOT_HEIGHT);

        // UI
        game.font.draw(game.batch, "Pontos: " + pontos, LARGURA_AVALANCHE + 10, VIRTUAL_HEIGHT - 20);
        game.font.draw(game.batch, "Vidas: " + vidas, LARGURA_AVALANCHE + 10, VIRTUAL_HEIGHT - 50);
        String speedText = String.format("Velocidade: %.0f", playerSpeedX);
        game.font.draw(game.batch, speedText, LARGURA_AVALANCHE + 10, VIRTUAL_HEIGHT - 80);

        if (!podeLevarDano) {
            game.font.draw(game.batch, "INVENCIVEL!", LARGURA_AVALANCHE + 10, VIRTUAL_HEIGHT - 110);
        }

        game.batch.end();

        // Game Over
        if (vidas <= 0) {
            Gdx.app.log("GameScreen", "Game Over! Pontos finais: " + pontos);
            game.setScreen(new MenuScreen(game));
            dispose();
        }
    }

    @Override
    public void dispose() {
        if (background != null) background.dispose();
        if (playerTexture != null) playerTexture.dispose();
        if (botTexture != null) botTexture.dispose();
        if (shapeRenderer != null) shapeRenderer.dispose();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void show() {
        if (game.backgroundMusic != null && !game.backgroundMusic.isPlaying()) {
            game.backgroundMusic.play();
        }
    }

    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}
}
